# 🎯 Sistema de Cruces Automáticos con Marcado en Verde

## ✨ ¡Tu archivo ya fue procesado!

**Resultados del análisis:**
- ✅ **148 cruces detectados** automáticamente
- 🏦 **8 cuentas bancarias** analizadas
- 📊 **1,226 registros** procesados
- 🎨 **Archivo con cruces marcados en VERDE** generado

### 📋 Distribución de cruces por cuenta:
1. **Bancolombia Cta 690**: 176 cruces
2. **Bancolombia Cta 1331**: 102 cruces
3. **Banco de Bogotá 0553**: 10 cruces
4. **Banco Colpatria**: 8 cruces

---

## 🚀 Instalación y Uso

### Opción 1: Línea de Comandos (Rápido)

```bash
# Instalar dependencias
pip install pandas openpyxl

# Ejecutar script
python cruces_automaticos.py
```

El archivo con cruces marcados se genera automáticamente en:
`CCS_Memorando_CON_CRUCES.xlsx`

### Opción 2: Aplicación Web (Recomendado)

```bash
# Instalar dependencias
pip install flask pandas openpyxl werkzeug

# Iniciar aplicación web
python app_cruces.py

# Abrir navegador
http://localhost:5003
```

---

## 🎨 ¿Cómo funciona el marcado?

### 1. **Busca valores exactos**
   - Compara todos los valores en todas las hojas
   - Tolerancia configurable (por defecto: 1 centavo)

### 2. **Verifica fechas** (opcional)
   - Máximo 3 días de diferencia por defecto
   - Configurable según necesidad

### 3. **Marca en VERDE**
   - Celdas de valor: 🟢 Verde
   - Columna Comentario: "Cruce 1", "Cruce 2", etc.
   - Formato original intacto

### 4. **Ejemplos de cruces detectados:**

| ID | Valor | Hoja 1 | Hoja 2 |
|----|-------|--------|--------|
| 1 | $3,000,000 | Bancolombia Cta 1331 | Bancolombia Cta 1331 |
| 2 | $2,990,240 | Bancolombia Cta 1331 | Banco de Bogotá 0553 |
| 3 | $20,500 | Bancolombia Cta 1331 | Banco de Bogotá 0553 |

---

## ⚙️ Configuración

### Tolerancia de Valor
```python
tolerancia = 0.01  # 1 centavo
tolerancia = 0.00  # Exacto
tolerancia = 1.00  # 1 peso
```

### Diferencia en Días
```python
dias_diferencia = 0  # Fecha exacta
dias_diferencia = 3  # ±3 días
dias_diferencia = 7  # ±1 semana
```

---

## 📁 Archivos Incluidos

```
├── CCS_Memorando_CON_CRUCES.xlsx    ✅ Archivo con cruces marcados
├── cruces_automaticos.py             🐍 Script de línea de comandos
├── app_cruces.py                     🌐 Aplicación web Flask
├── templates/
│   └── cruces.html                   💻 Interfaz web moderna
└── README_CRUCES.md                  📖 Este archivo
```

---

## 🎯 Características del Sistema

### ✅ Lo que SÍ hace:
- Busca valores exactos (con tolerancia mínima)
- Compara fechas (opcional)
- Cruza entre múltiples hojas
- Cruza dentro de la misma hoja
- Marca celdas en VERDE
- Agrega comentarios "Cruce 1", "Cruce 2"
- Mantiene formato original del Excel
- Agrega columna "Comentario" si no existe

### ❌ Lo que NO hace:
- No modifica valores
- No elimina filas
- No cambia fórmulas
- No altera otros formatos (bordes, colores originales)

---

## 💡 Casos de Uso

### 1. **Conciliación Bancaria**
Cruza movimientos entre extracto bancario y libro mayor

### 2. **Validación de Transferencias**
Verifica que transferencias aparezcan en ambas cuentas

### 3. **Depósitos y Retiros**
Identifica movimientos que coinciden en fecha y valor

### 4. **Auditoría**
Detecta automáticamente registros duplicados o relacionados

---

## 🔧 Personalización

### Modificar Colores

En `cruces_automaticos.py` línea 10:

```python
# Verde claro (actual)
self.green_fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")

# Verde más fuerte
self.green_fill = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")

# Amarillo
self.green_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
```

### Cambiar Texto de Comentarios

Línea 186:

```python
comentario = f"Cruce {cruce_id}"  # Actual

# Opciones:
comentario = f"✅ Cruce {cruce_id}"
comentario = f"Match #{cruce_id}"
comentario = f"Conciliado {cruce_id}"
```

---

## 🎓 Interpretación de Resultados

### ¿Qué significan los cruces?

Un **cruce** indica que:
1. Dos registros tienen el **mismo valor** (dentro de la tolerancia)
2. Las **fechas coinciden** (dentro de los días permitidos)
3. Los registros están en **hojas diferentes** O en la **misma hoja**

### Ejemplo Real:

```
Cruce 1: $72,000.00
- Bancolombia Cta 1331, Fila 19, Fecha: 2025-01-29
- Bancolombia Cta 690, Fila 45, Fecha: 2025-01-29

✅ Valor exacto ✅ Misma fecha ✅ Cuentas diferentes
→ Probable transferencia entre cuentas
```

---

## 📊 Estadísticas de Tu Archivo

### Resumen Ejecutivo:
- 📁 8 hojas procesadas
- 📝 1,226 registros analizados
- ✅ 148 cruces detectados (12% de conciliación)
- 🎨 296 celdas marcadas en verde

### Cuentas con Más Cruces:
1. **Bancolombia Cta 690**: 176 cruces (59.4%)
2. **Bancolombia Cta 1331**: 102 cruces (34.5%)
3. **Banco de Bogotá 0553**: 10 cruces (3.4%)
4. **Banco Colpatria**: 8 cruces (2.7%)

---

## 🆘 Problemas Comunes

### "No se encontraron cruces"
- Verifica que los valores sean exactamente iguales
- Aumenta la tolerancia (ej: 1.00 en lugar de 0.01)
- Aumenta los días de diferencia
- Revisa que las columnas se llamen "Valor" y "Fecha Contabilización"

### "Error al cargar archivo"
- Asegúrate que sea un archivo .xlsx válido
- Verifica que tenga encabezados "Fecha Contabilización" y "Valor"
- No uses archivos con protección de contraseña

### "Archivo se corrompe"
- Haz una copia de seguridad antes
- El sistema está diseñado para no alterar el formato
- Reporta el error si persiste

---

## 🎉 Próximos Pasos

1. **Revisa el archivo generado**
   - Abre `CCS_Memorando_CON_CRUCES.xlsx`
   - Busca las celdas verdes
   - Lee los comentarios "Cruce X"

2. **Valida los cruces manualmente**
   - No todos los cruces son correctos automáticamente
   - Verifica especialmente valores comunes ($50,000, $100,000)

3. **Ajusta parámetros si es necesario**
   - Si hay muchos falsos positivos: reduce tolerancia
   - Si faltan cruces obvios: aumenta días de diferencia

4. **Automatiza el proceso**
   - Usa la aplicación web para futuros archivos
   - Configura parámetros personalizados por cuenta

---

## 💼 Soporte Técnico

**Desarrollado para:**
- Contadores y auditores
- Áreas de tesorería
- Conciliación bancaria
- Control interno

**Tecnología:**
- Python 3.8+
- openpyxl para Excel
- pandas para análisis de datos
- Flask para interfaz web

---

## ✅ Checklist de Validación

Antes de usar el archivo con cruces:

- [ ] Revisar primeros 10 cruces manualmente
- [ ] Verificar que valores coincidan exactamente
- [ ] Confirmar que fechas tengan sentido
- [ ] Validar que cruces entre cuentas sean transferencias reales
- [ ] Documentar cruces que requieran investigación

---

**¿Listo para automatizar tus conciliaciones?** 🚀

```bash
python cruces_automaticos.py
```

O para interfaz web:

```bash
python app_cruces.py
# Abre: http://localhost:5003
```
