from flask import Flask, render_template, request, jsonify, send_file
import openpyxl
from openpyxl.styles import PatternFill, Font
import pandas as pd
from datetime import datetime
import os
from werkzeug.utils import secure_filename
from collections import defaultdict

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = '/tmp/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

class ExcelCrossMarker:
    def __init__(self):
        self.wb = None
        self.cruces = []
        self.registros_por_hoja = {}
        self.green_fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
        self.file_path = None
        
    def cargar_archivo(self, file_path):
        self.file_path = file_path
        self.wb = openpyxl.load_workbook(file_path)
        return True
    
    def extraer_registros_de_hoja(self, sheet_name):
        ws = self.wb[sheet_name]
        header_row = None
        fecha_col = None
        valor_col = None
        comentario_col = None
        
        for row_idx in range(1, min(50, ws.max_row + 1)):
            for col_idx in range(1, ws.max_column + 1):
                cell_value = ws.cell(row_idx, col_idx).value
                if cell_value and 'Fecha Contabilización' in str(cell_value):
                    header_row = row_idx
                    break
            if header_row:
                break
        
        if not header_row:
            return []
        
        for col_idx in range(1, ws.max_column + 1):
            cell_value = ws.cell(header_row, col_idx).value
            if cell_value:
                cell_str = str(cell_value).strip()
                if 'Fecha Contabilización' in cell_str:
                    fecha_col = col_idx
                elif 'Valor' in cell_str and valor_col is None:
                    valor_col = col_idx
                elif 'Comentario' in cell_str:
                    comentario_col = col_idx
        
        if not valor_col:
            return []
        
        if not comentario_col:
            comentario_col = ws.max_column + 1
            ws.cell(header_row, comentario_col).value = "Comentario"
            ws.cell(header_row, comentario_col).fill = PatternFill(
                start_color="4472C4", end_color="4472C4", fill_type="solid"
            )
            ws.cell(header_row, comentario_col).font = Font(color="FFFFFF", bold=True)
        
        registros = []
        for row_idx in range(header_row + 1, ws.max_row + 1):
            valor = ws.cell(row_idx, valor_col).value
            
            if valor is None:
                continue
            
            try:
                valor_num = float(valor)
            except (ValueError, TypeError):
                continue
            
            desc_cell = None
            for col in range(1, ws.max_column + 1):
                cell_val = ws.cell(row_idx, col).value
                if cell_val and isinstance(cell_val, str):
                    if any(x in cell_val.lower() for x in ['saldo', 'diferencia', 'total', 'sin registrar']):
                        desc_cell = True
                        break
            
            if desc_cell:
                continue
            
            fecha = None
            if fecha_col:
                fecha_val = ws.cell(row_idx, fecha_col).value
                if isinstance(fecha_val, datetime):
                    fecha = fecha_val
                elif fecha_val:
                    try:
                        fecha = pd.to_datetime(fecha_val)
                    except:
                        pass
            
            registro = {
                'hoja': sheet_name,
                'fila': row_idx,
                'fecha': fecha,
                'valor': valor_num,
                'valor_col': valor_col,
                'comentario_col': comentario_col
            }
            
            registros.append(registro)
        
        return registros
    
    def buscar_cruces(self, tolerancia=0.01, dias_diferencia=3):
        todos_registros = []
        for sheet_name in self.wb.sheetnames:
            registros = self.extraer_registros_de_hoja(sheet_name)
            todos_registros.extend(registros)
            self.registros_por_hoja[sheet_name] = registros
        
        cruces_encontrados = []
        registros_cruzados = set()
        
        for i, reg1 in enumerate(todos_registros):
            if i in registros_cruzados:
                continue
            
            for j, reg2 in enumerate(todos_registros):
                if j <= i or j in registros_cruzados:
                    continue
                
                if abs(reg1['valor'] - reg2['valor']) <= tolerancia:
                    if reg1['fecha'] and reg2['fecha']:
                        diff_dias = abs((reg1['fecha'] - reg2['fecha']).days)
                        if diff_dias > dias_diferencia:
                            continue
                    
                    cruce = {
                        'id': len(cruces_encontrados) + 1,
                        'reg1': reg1,
                        'reg2': reg2,
                        'valor': reg1['valor'],
                        'fecha1': reg1['fecha'].strftime('%Y-%m-%d') if reg1['fecha'] else 'N/A',
                        'fecha2': reg2['fecha'].strftime('%Y-%m-%d') if reg2['fecha'] else 'N/A'
                    }
                    
                    cruces_encontrados.append(cruce)
                    registros_cruzados.add(i)
                    registros_cruzados.add(j)
                    break
        
        self.cruces = cruces_encontrados
        return cruces_encontrados
    
    def marcar_cruces(self):
        for cruce in self.cruces:
            cruce_id = cruce['id']
            comentario = f"Cruce {cruce_id}"
            
            reg1 = cruce['reg1']
            ws1 = self.wb[reg1['hoja']]
            valor_cell = ws1.cell(reg1['fila'], reg1['valor_col'])
            valor_cell.fill = self.green_fill
            comentario_cell = ws1.cell(reg1['fila'], reg1['comentario_col'])
            comentario_cell.value = comentario
            comentario_cell.fill = self.green_fill
            
            reg2 = cruce['reg2']
            ws2 = self.wb[reg2['hoja']]
            valor_cell = ws2.cell(reg2['fila'], reg2['valor_col'])
            valor_cell.fill = self.green_fill
            comentario_cell = ws2.cell(reg2['fila'], reg2['comentario_col'])
            comentario_cell.value = comentario
            comentario_cell.fill = self.green_fill
    
    def guardar_archivo(self, output_path):
        self.wb.save(output_path)
        
    def get_estadisticas(self):
        cruces_por_hoja = defaultdict(int)
        for cruce in self.cruces:
            cruces_por_hoja[cruce['reg1']['hoja']] += 1
            cruces_por_hoja[cruce['reg2']['hoja']] += 1
        
        return {
            'total_cruces': len(self.cruces),
            'total_hojas': len(self.wb.sheetnames),
            'hojas': list(self.wb.sheetnames),
            'cruces_por_hoja': dict(cruces_por_hoja)
        }

marker = ExcelCrossMarker()

@app.route('/')
def index():
    return render_template('cruces.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No se recibió archivo'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'Archivo vacío'}), 400
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
        file.save(file_path)
        
        marker.cargar_archivo(file_path)
        
        return jsonify({
            'success': True,
            'mensaje': 'Archivo cargado correctamente',
            'hojas': marker.wb.sheetnames
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/buscar_cruces', methods=['POST'])
def buscar_cruces():
    try:
        config = request.json
        tolerancia = float(config.get('tolerancia', 0.01))
        dias_diferencia = int(config.get('dias_diferencia', 3))
        
        cruces = marker.buscar_cruces(tolerancia, dias_diferencia)
        stats = marker.get_estadisticas()
        
        cruces_data = []
        for cruce in cruces[:100]:  # Primeros 100 para UI
            cruces_data.append({
                'id': cruce['id'],
                'valor': float(cruce['valor']),
                'hoja1': cruce['reg1']['hoja'],
                'hoja2': cruce['reg2']['hoja'],
                'fecha1': cruce['fecha1'],
                'fecha2': cruce['fecha2'],
                'fila1': cruce['reg1']['fila'],
                'fila2': cruce['reg2']['fila']
            })
        
        return jsonify({
            'success': True,
            'cruces': cruces_data,
            'stats': stats
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/marcar_y_exportar', methods=['POST'])
def marcar_y_exportar():
    try:
        marker.marcar_cruces()
        
        output_path = os.path.join(app.config['UPLOAD_FOLDER'], 'archivo_con_cruces.xlsx')
        marker.guardar_archivo(output_path)
        
        return send_file(
            output_path,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=f'archivo_con_cruces_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5003)
