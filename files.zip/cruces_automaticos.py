import openpyxl
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter
import pandas as pd
from datetime import datetime
from collections import defaultdict

class ExcelCrossMarker:
    def __init__(self):
        self.wb = None
        self.cruces = []
        self.registros_por_hoja = {}
        # Color verde para celdas cruzadas
        self.green_fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
        
    def cargar_archivo(self, file_path):
        """Carga el archivo Excel manteniendo formato"""
        print("📁 Cargando archivo Excel...")
        self.wb = openpyxl.load_workbook(file_path)
        print(f"   ✓ {len(self.wb.sheetnames)} hojas detectadas")
        return True
    
    def extraer_registros_de_hoja(self, sheet_name):
        """Extrae registros con valores de una hoja específica"""
        ws = self.wb[sheet_name]
        
        # Buscar fila de encabezados
        header_row = None
        fecha_col = None
        valor_col = None
        comentario_col = None
        
        for row_idx in range(1, min(50, ws.max_row + 1)):
            for col_idx in range(1, ws.max_column + 1):
                cell_value = ws.cell(row_idx, col_idx).value
                if cell_value and 'Fecha Contabilización' in str(cell_value):
                    header_row = row_idx
                    break
            if header_row:
                break
        
        if not header_row:
            return []
        
        # Identificar columnas importantes
        for col_idx in range(1, ws.max_column + 1):
            cell_value = ws.cell(header_row, col_idx).value
            if cell_value:
                cell_str = str(cell_value).strip()
                if 'Fecha Contabilización' in cell_str:
                    fecha_col = col_idx
                elif 'Valor' in cell_str and valor_col is None:
                    valor_col = col_idx
                elif 'Comentario' in cell_str:
                    comentario_col = col_idx
        
        if not valor_col:
            return []
        
        # Agregar columna Comentario si no existe
        if not comentario_col:
            comentario_col = ws.max_column + 1
            ws.cell(header_row, comentario_col).value = "Comentario"
            ws.cell(header_row, comentario_col).fill = PatternFill(
                start_color="4472C4", end_color="4472C4", fill_type="solid"
            )
            ws.cell(header_row, comentario_col).font = Font(color="FFFFFF", bold=True)
        
        # Extraer registros
        registros = []
        for row_idx in range(header_row + 1, ws.max_row + 1):
            valor = ws.cell(row_idx, valor_col).value
            
            if valor is None:
                continue
            
            # Intentar convertir a número
            try:
                valor_num = float(valor)
            except (ValueError, TypeError):
                continue
            
            # Saltar filas que son totales o resúmenes
            desc_cell = None
            for col in range(1, ws.max_column + 1):
                cell_val = ws.cell(row_idx, col).value
                if cell_val and isinstance(cell_val, str):
                    if any(x in cell_val.lower() for x in ['saldo', 'diferencia', 'total', 'sin registrar']):
                        desc_cell = True
                        break
            
            if desc_cell:
                continue
            
            # Obtener fecha
            fecha = None
            if fecha_col:
                fecha_val = ws.cell(row_idx, fecha_col).value
                if isinstance(fecha_val, datetime):
                    fecha = fecha_val
                elif fecha_val:
                    try:
                        fecha = pd.to_datetime(fecha_val)
                    except:
                        pass
            
            registro = {
                'hoja': sheet_name,
                'fila': row_idx,
                'fecha': fecha,
                'valor': valor_num,
                'valor_col': valor_col,
                'comentario_col': comentario_col
            }
            
            registros.append(registro)
        
        return registros
    
    def buscar_cruces(self):
        """Busca cruces entre todas las hojas"""
        print("\n🔍 Buscando cruces automáticos...")
        
        # Extraer todos los registros de todas las hojas
        todos_registros = []
        for sheet_name in self.wb.sheetnames:
            print(f"   Procesando {sheet_name}...")
            registros = self.extraer_registros_de_hoja(sheet_name)
            todos_registros.extend(registros)
            self.registros_por_hoja[sheet_name] = registros
        
        print(f"\n   ✓ Total registros encontrados: {len(todos_registros)}")
        
        # Buscar cruces por valor exacto
        cruces_encontrados = []
        registros_cruzados = set()
        
        for i, reg1 in enumerate(todos_registros):
            if i in registros_cruzados:
                continue
            
            for j, reg2 in enumerate(todos_registros):
                if j <= i or j in registros_cruzados:
                    continue
                
                # Verificar si el valor es exactamente igual
                if abs(reg1['valor'] - reg2['valor']) < 0.01:  # Tolerancia de centavos
                    # Si tienen fecha, verificar que coincida (opcional - comentar si no se quiere)
                    if reg1['fecha'] and reg2['fecha']:
                        diff_dias = abs((reg1['fecha'] - reg2['fecha']).days)
                        if diff_dias > 3:  # Máximo 3 días de diferencia
                            continue
                    
                    # Cruce encontrado!
                    cruce = {
                        'id': len(cruces_encontrados) + 1,
                        'reg1': reg1,
                        'reg2': reg2,
                        'valor': reg1['valor']
                    }
                    
                    cruces_encontrados.append(cruce)
                    registros_cruzados.add(i)
                    registros_cruzados.add(j)
                    break
        
        self.cruces = cruces_encontrados
        print(f"\n   ✅ {len(cruces_encontrados)} cruces detectados!")
        return cruces_encontrados
    
    def marcar_cruces(self):
        """Marca los cruces en verde y agrega comentarios"""
        print("\n✏️  Marcando cruces en el archivo...")
        
        for cruce in self.cruces:
            cruce_id = cruce['id']
            comentario = f"Cruce {cruce_id}"
            
            # Marcar registro 1
            reg1 = cruce['reg1']
            ws1 = self.wb[reg1['hoja']]
            
            # Pintar celda de valor en verde
            valor_cell = ws1.cell(reg1['fila'], reg1['valor_col'])
            valor_cell.fill = self.green_fill
            
            # Agregar comentario
            comentario_cell = ws1.cell(reg1['fila'], reg1['comentario_col'])
            comentario_cell.value = comentario
            comentario_cell.fill = self.green_fill
            
            # Marcar registro 2
            reg2 = cruce['reg2']
            ws2 = self.wb[reg2['hoja']]
            
            # Pintar celda de valor en verde
            valor_cell = ws2.cell(reg2['fila'], reg2['valor_col'])
            valor_cell.fill = self.green_fill
            
            # Agregar comentario
            comentario_cell = ws2.cell(reg2['fila'], reg2['comentario_col'])
            comentario_cell.value = comentario
            comentario_cell.fill = self.green_fill
        
        print(f"   ✓ {len(self.cruces)} cruces marcados en verde")
    
    def guardar_archivo(self, output_path):
        """Guarda el archivo con los cruces marcados"""
        print(f"\n💾 Guardando archivo...")
        self.wb.save(output_path)
        print(f"   ✓ Archivo guardado: {output_path}")
    
    def generar_reporte(self):
        """Genera un reporte de los cruces encontrados"""
        print("\n" + "=" * 100)
        print("📊 REPORTE DE CRUCES")
        print("=" * 100)
        print()
        
        if not self.cruces:
            print("   ⚠️  No se encontraron cruces")
            return
        
        print(f"{'ID':<10} {'Valor':<20} {'Hoja 1':<30} {'Hoja 2':<30}")
        print("-" * 100)
        
        for cruce in self.cruces[:20]:  # Mostrar primeros 20
            print(f"{cruce['id']:<10} "
                  f"${cruce['valor']:>15,.2f}    "
                  f"{cruce['reg1']['hoja'][:28]:<30} "
                  f"{cruce['reg2']['hoja'][:28]:<30}")
        
        if len(self.cruces) > 20:
            print(f"\n   ... y {len(self.cruces) - 20} cruces más")
        
        print()
        print(f"   Total cruces: {len(self.cruces)}")
        
        # Estadísticas por hoja
        cruces_por_hoja = defaultdict(int)
        for cruce in self.cruces:
            cruces_por_hoja[cruce['reg1']['hoja']] += 1
            cruces_por_hoja[cruce['reg2']['hoja']] += 1
        
        print("\n   📈 Cruces por hoja:")
        for hoja, count in sorted(cruces_por_hoja.items(), key=lambda x: x[1], reverse=True):
            print(f"      {hoja[:40]}: {count} cruces")

def main():
    print("=" * 100)
    print("🏦 SISTEMA DE CRUCES AUTOMÁTICOS CON MARCADO EN VERDE")
    print("=" * 100)
    print()
    
    # Crear instancia
    marker = ExcelCrossMarker()
    
    # Cargar archivo
    input_file = '/mnt/user-data/uploads/CCS_Memorando_Definitivo_Ctas_Bancarias_Enero_2026.xlsx'
    marker.cargar_archivo(input_file)
    
    # Buscar cruces
    cruces = marker.buscar_cruces()
    
    # Generar reporte
    marker.generar_reporte()
    
    # Marcar cruces en verde
    if cruces:
        marker.marcar_cruces()
        
        # Guardar archivo modificado
        output_file = '/mnt/user-data/outputs/CCS_Memorando_CON_CRUCES.xlsx'
        marker.guardar_archivo(output_file)
        
        print("\n" + "=" * 100)
        print("✨ PROCESO COMPLETADO")
        print("=" * 100)
        print()
        print(f"   📁 Archivo original: {input_file}")
        print(f"   📁 Archivo con cruces: {output_file}")
        print()
        print("   ✅ Los cruces están marcados en VERDE")
        print("   ✅ Los comentarios indican 'Cruce 1', 'Cruce 2', etc.")
        print("   ✅ El formato original se mantuvo intacto")
        print()
    else:
        print("\n⚠️  No se encontraron cruces para marcar")

if __name__ == '__main__':
    main()
